<?php

class Unescaped
{
    public $title = 'Bear > Shark';
}
