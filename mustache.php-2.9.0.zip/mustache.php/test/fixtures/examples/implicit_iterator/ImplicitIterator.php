<?php

class ImplicitIterator
{
    public $data = array('Donkey Kong', 'Luigi', 'Mario', 'Peach', 'Yoshi');
}
