<?php

class Escaped
{
    public $title = '"Bear" > "Shark"';
}
